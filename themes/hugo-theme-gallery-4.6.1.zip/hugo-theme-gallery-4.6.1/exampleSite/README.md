# Example site for hugo-theme-gallery

## Installation

```
# Install Hugo module
hugo mod get

# Pull example images from Unsplash
./pull-images.sh
```
