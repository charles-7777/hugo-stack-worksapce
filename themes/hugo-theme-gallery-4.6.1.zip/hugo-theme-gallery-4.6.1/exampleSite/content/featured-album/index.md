---
date: 2023-01-12
title: Featured Album
params:
  featured: true
  private: true # do not show in list, only as feature
description: This is a featured album. It is private, so it is only shown on the homepage.
resources:
  - src: jeremy-bishop-pjszS6Q2g_Y-unsplash.jpg
    params:
      cover: true
---
