---
date: 2023-04-01
title: Cats
sort_by: Name
categories: ["animals", "nature"]
params:
  featured_image: manja-vitolic-gKXKBY-C-Dk-unsplash.jpg
resources:
  - src: alexander-london-mJaD10XeD7w-unsplash.jpg
    title: Brown tabby cat on white stairs by Alexander London
  - src: amber-kipp-75715CVEJhI-unsplash.jpg
    title: Selective focus photography of orange and white cat on brown table by Amber Kipp
  - src: manja-vitolic-gKXKBY-C-Dk-unsplash.jpg
    title: "Gipsy the Cat was sitting on a bookshelf one afternoon and just stared right at me, kinda saying: “Will you take a picture already?”"
    params:
      cover: true
  - src: michael-sum-LEpfefQf4rU-unsplash.jpg
    title: This is the cutest and loveliest cat I have ever met in my life. He is BU BU, a cat with 6 fingers, which is unusual, but in fact, smarter than any cat. He meows every time he sees me, and jumps to my bed and sits with me.
---
